If you are unable to see chart using any of the HTML files then check for the following:

1. Do you have Silverlight 4.0 installed? If not, then install Silverlight.

2. If you have Silverlight 4.0 installed & still not able to see the chart. Then, select HTML file. Right click and select Properties > General. 

   a. If you see Unblock button, click on it. Then click on Ok button.

   b. Browse the HTML file in any web browser.
