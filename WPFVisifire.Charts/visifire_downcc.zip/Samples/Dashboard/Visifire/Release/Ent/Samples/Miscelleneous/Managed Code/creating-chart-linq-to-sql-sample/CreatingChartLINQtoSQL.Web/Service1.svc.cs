﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace _11.LINQtoSQL.Web
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service1 : IService1
    {

        public List<Product> GetChartData()
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var query = from c in db.Products select c;
            return query.Take(10).ToList();
        }
    }
}
