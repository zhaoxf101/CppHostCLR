﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Visifire.Gauges;
using Visifire.Commons;

namespace LinearGauge
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Call function to create gauge
            CreateGauge();
        }

        private void CreateGauge()
        {
            // Create a gauge
            Gauge gauge = new Gauge();
            gauge.Width = 120;
           

            // Set Type property in Gauge
            gauge.Type = GaugeTypes.Linear;

            // Create a Bar Indicator
            BarIndicator indicator = new BarIndicator();
            indicator.Value = 40;

            // Add indicator to Indicators collection of gauge
            gauge.Indicators.Add(indicator);

            // Add gauge to the LayoutRoot for display
            ContentPanel.Children.Add(gauge);
        }
    }
}
