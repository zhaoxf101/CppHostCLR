﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace DataBinding
{
    public partial class MainPage : UserControl
    {
        DateTime dt1 = new DateTime(2010, 8, 1);
        Random rn = new Random();

        public MainPage()
        {
            InitializeComponent();

            // Populate collection of Values
            for (int i = 0; i < 1000; i++)
            {
                values.Add(new Value() { XValue = dt1, YValue = rn.Next(1, 50) });
                dt1 = dt1.AddMinutes(1);
            }

            // Setting values collection as source
            MyGrid.ItemsSource = values;
        }
        
        ObservableCollection<Value> values = new ObservableCollection<Value>();
    }
}
