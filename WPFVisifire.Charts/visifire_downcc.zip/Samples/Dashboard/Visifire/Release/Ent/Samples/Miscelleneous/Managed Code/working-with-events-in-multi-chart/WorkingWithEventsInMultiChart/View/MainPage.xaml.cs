﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using Visifire.Charts;
using Visifire.Commons;

namespace WorkingWithEventsInMultiChart
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            //Attach even to Multi-Series Chart
            MutiChart1.OnDataPointMouseLeftButtonUp += new EventHandler<MouseButtonEventArgs>(MutiChart1_OnDataPointMouseLeftButtonUp);
        }

        void MutiChart1_OnDataPointMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("AxisXLabel:" + (sender as DataPoint).AxisXLabel.ToString() + "   YValue:" +(sender as DataPoint).YValue.ToString());
        }
    }
}
