Current version of Visifire supports Silverlight 4.0.

If you are working with web application then you need to work with Visifire and JavaScript. In this case you just need to install Silverlight plug-in for your browser. Also note that you don't have to install any .Net Framework except Silverlight browser plug-in.

If you are creating Chart in a Silverlight application, you need to add reference to FJ.Core.dll in order to export the chart as image.