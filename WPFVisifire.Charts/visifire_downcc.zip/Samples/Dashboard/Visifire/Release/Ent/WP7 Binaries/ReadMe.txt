Setup your Windows Phone Development Environment :
http://www.silverlight.net/getstarted/devices/windows-phone/

Add reference to SLWpVisifire.Charts.dll in your Windows Phone Application.