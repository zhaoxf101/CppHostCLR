﻿Download Visifire and add reference to following dlls and run the application.

1)	FJ.Core.dll
2)	SLVisifire.Charts.dll
3)	SLVisifire.Gauges.dll