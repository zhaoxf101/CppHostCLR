Current version of Visifire for WPF supports .Net Framework 3.5 and above.

In a WPF Chart application, reference for WPFToolkit.dll is also required. WPFToolkit is being used in Visifire in order to take help of VisualStateManager for ZoomBar. Reference to WPFToolkit is not required in Gauge application.